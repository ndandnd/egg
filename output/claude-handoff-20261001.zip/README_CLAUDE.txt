START HERE: doc/CLAUDE_RESEARCH_HANDOFF_20261001.md

The opening block is a suggested prompt to Claude. This packet is for an
independent assessment, not automatic approval of the prepared next experiment.
All Codex schedules are PAUSED. Existing submitted cluster jobs were left intact.

Suggested reading order:
1. Handoff (about 2,000 words).
2. Campaign ROUTE_PROPOSAL_TRAIN_V7_RESULTS and V7_COST_COMPONENT_DIAGNOSIS.
3. Campaign ROUTE_GRAPH_V6_RESULTS and ROUTE_FAMILIES_V5_RESULTS.
4. Historical v0.10 PDF for the theoretical research; it predates current ML.
5. Prepared protocols and operating receipts only as needed.

Paths in this ZIP preserve the repository layout. The SHA-256 contents manifest
is doc/CLAUDE_HANDOFF_BUNDLE_MANIFEST_20261001.json. Raw models and full experimental
archives are not included. No secrets, private GIRO data or reserved test outcomes
are part of this selected packet. The latest pause overrides historical plans.
